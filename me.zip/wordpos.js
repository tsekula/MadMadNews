var WordPOS = require('wordpos'),
    wordpos = new WordPOS();
    
    //wordpos.getPOS('I give my body to you', console.log);
    wordpos.randVerb(console.log);
  